import { MapPin, AlertCircle, FileText, Home, Settings } from "lucide-react";
import { useState } from "react";

interface BottomNavProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function BottomNav({ onNavigate, currentPage }: BottomNavProps) {
  const navItems = [
    { id: "home", label: "الرئيسية", icon: Home },
    { id: "map", label: "المساعد الذكي", icon: AlertCircle },
    { id: "alerts", label: "الإعدادات", icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 border-t border-secondary/20 bg-white shadow-lg">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-1 flex-col items-center justify-center gap-1 py-3 transition-colors ${
                isActive
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
