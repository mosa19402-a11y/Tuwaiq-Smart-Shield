import { MapPin, Menu, X, Shield } from "lucide-react";
import { useState } from "react";

interface MobileHeaderProps {
  title: string;
  showMenu?: boolean;
}

export default function MobileHeader({ title, showMenu = false }: MobileHeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 bg-primary text-white border-b border-secondary/20">
        <div className="flex items-center justify-between px-4 py-3">
          {/* Logo and Title */}
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-bold">TSH درع طويق الذكي</span>
          </div>

          {/* Menu Button */}
          {showMenu && (
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2 hover:bg-secondary/20 rounded-lg"
            >
              {menuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
          )}
        </div>

        {/* Mobile Menu */}
        {menuOpen && showMenu && (
          <div className="border-t border-secondary/20 bg-secondary/10 px-4 py-3 space-y-2">
            <a href="#" className="block text-sm font-medium text-white py-2">
              تسجيل الدخول
            </a>
            <a href="#" className="block text-sm font-medium text-white py-2">
              الإعدادات
            </a>
            <a href="#" className="block text-sm font-medium text-white py-2">
              الدعم
            </a>
          </div>
        )}
      </header>
    </>
  );
}
