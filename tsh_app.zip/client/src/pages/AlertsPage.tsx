import { AlertTriangle, AlertCircle, Info } from "lucide-react";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";

export default function AlertsPage() {
  const { data: alerts = [], isLoading } = trpc.alerts.getActive.useQuery();

  const getRiskColor = (riskLevel: number) => {
    if (riskLevel >= 4) return "border-l-red-500 bg-red-50";
    if (riskLevel >= 3) return "border-l-orange-500 bg-orange-50";
    if (riskLevel >= 2) return "border-l-yellow-500 bg-yellow-50";
    return "border-l-blue-500 bg-blue-50";
  };

  const getRiskIcon = (riskLevel: number) => {
    if (riskLevel >= 4) return <AlertTriangle className="h-5 w-5 text-red-600" />;
    if (riskLevel >= 3) return <AlertCircle className="h-5 w-5 text-orange-600" />;
    return <Info className="h-5 w-5 text-blue-600" />;
  };

  const getRiskLabel = (riskLevel: number) => {
    const labels = ["", "منخفض", "متوسط", "عالي", "حرج", "خطير جداً"];
    return labels[riskLevel] || "غير معروف";
  };

  return (
    <div className="space-y-4 p-4 pb-24">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-primary mb-2">التنبيهات النشطة</h1>
        <p className="text-sm text-muted-foreground">
          {alerts.length} تنبيه نشط حالياً
        </p>
      </div>

      {isLoading ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      ) : alerts.length === 0 ? (
        <Card className="p-8 rounded-2xl text-center bg-green-50 border border-green-200">
          <div className="flex justify-center mb-3">
            <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
              <AlertCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <h3 className="font-bold text-green-900 mb-1">كل شيء آمن</h3>
          <p className="text-sm text-green-700">
            لا توجد تنبيهات نشطة حالياً
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => (
            <Card
              key={alert.id}
              className={`p-4 rounded-2xl border-l-4 ${getRiskColor(alert.riskLevel)}`}
            >
              <div className="flex gap-3">
                <div className="flex-shrink-0 mt-1">
                  {getRiskIcon(alert.riskLevel)}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold text-foreground">{alert.title}</h3>
                    <span className="text-xs px-2 py-1 rounded-full font-medium bg-white">
                      {getRiskLabel(alert.riskLevel)}
                    </span>
                  </div>
                  
                  {alert.description && (
                    <p className="text-sm text-muted-foreground mb-2">
                      {alert.description}
                    </p>
                  )}
                  
                  <div className="flex justify-between items-end">
                    <p className="text-xs text-muted-foreground">
                      📍 {alert.location}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(alert.createdAt).toLocaleDateString("ar-SA")}
                    </p>
                  </div>

                  {alert.type && (
                    <div className="mt-2 text-xs">
                      <span className="inline-block px-2 py-1 rounded bg-white/50">
                        {alert.type === "rockfall"
                          ? "انهيار صخري"
                          : alert.type === "weather"
                          ? "ظروف جوية"
                          : alert.type === "sensor"
                          ? "حساس"
                          : "بلاغ"}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* معلومات إضافية */}
      <Card className="p-4 rounded-2xl bg-blue-50 border border-blue-200 mt-6">
        <h3 className="font-bold text-blue-900 mb-2">مستويات الخطورة</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-blue-500"></div>
            <span className="text-blue-800">منخفض - معلومات عامة</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
            <span className="text-yellow-800">متوسط - انتبه</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-orange-500"></div>
            <span className="text-orange-800">عالي - احذر</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-red-500"></div>
            <span className="text-red-800">حرج - تجنب المنطقة</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
