import { useState } from "react";
import { HelpCircle, Star, Settings, MessageSquare, Shield, Phone } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import MobileHeader from "@/components/MobileHeader";
import BottomNav from "@/components/BottomNav";
import MapPage from "./MapPage";
import AlertsPage from "./AlertsPage";
import ReportsPage from "./ReportsPage";

export default function Home() {
  const [currentPage, setCurrentPage] = useState("home");
  const { user, isAuthenticated, logout } = useAuth();

  const renderPage = () => {
    switch (currentPage) {
      case "map":
        return <MapPage />;
      case "alerts":
        return <AlertsPage />;
      case "reports":
        return <ReportsPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-primary">
      <MobileHeader title={getPageTitle(currentPage)} />
      
      <main className="flex-1 overflow-y-auto pb-20">
        {renderPage()}
      </main>

      <BottomNav onNavigate={setCurrentPage} currentPage={currentPage} />
    </div>
  );
}

function getPageTitle(page: string): string {
  switch (page) {
    case "map":
      return "الخريطة";
    case "alerts":
      return "التنبيهات";
    case "reports":
      return "البلاغات";
    default:
      return "درع طويق الذكي";
  }
}

function HomePage() {
  return (
    <div className="space-y-4 p-4">
      {/* Header Section with Logo */}
      <div className="text-center text-white mb-6">
        <div className="flex justify-center mb-4">
          <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-secondary/50 backdrop-blur">
            <span className="text-2xl font-bold">TSH</span>
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-2">درع طويق الذكي</h1>
        <p className="text-sm text-white/80">
          منظومة سعودية حديثة لحماية الطرق الجبلية عبر الاستشعار الذكي الاصطناعي، وربط أبشر وتوكلنا.
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center text-white">
          <p className="text-3xl font-bold">20</p>
          <p className="text-xs mt-1">جبال مراقبة</p>
        </div>
        <div className="text-center text-white">
          <p className="text-3xl font-bold">2</p>
          <p className="text-xs mt-1">تنبيهات حرجة</p>
        </div>
        <div className="text-center text-white">
          <p className="text-3xl font-bold">5</p>
          <p className="text-xs mt-1">جهات متكاملة</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Button className="h-auto py-3 rounded-full bg-white text-primary font-semibold hover:bg-white/90">
          تكامل أبشر الرسمي
        </Button>
        <Button className="h-auto py-3 rounded-full bg-white text-primary font-semibold hover:bg-white/90">
          مزامنة توكلنا
        </Button>
      </div>

      {/* Phone Number Card */}
      <Card className="p-4 rounded-3xl flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">رقم أبشر للطوارئ</p>
          <p className="text-2xl font-bold">920020405</p>
        </div>
        <Phone className="h-6 w-6 text-primary" />
      </Card>

      {/* Features Cards */}
      <div className="space-y-3">
        <Card className="p-4 rounded-2xl flex items-center justify-between cursor-pointer hover:shadow-lg transition-shadow">
          <div>
            <h3 className="font-semibold text-foreground">المساعد الذكي</h3>
            <p className="text-xs text-muted-foreground mt-1">إجابات قوية بدعم الذكاء الاصطناعي</p>
          </div>
          <MessageSquare className="h-5 w-5 text-primary flex-shrink-0" />
        </Card>

        <Card className="p-4 rounded-2xl flex items-center justify-between cursor-pointer hover:shadow-lg transition-shadow">
          <div>
            <h3 className="font-semibold text-foreground">جودة الخدمة</h3>
            <p className="text-xs text-muted-foreground mt-1">راقب تجربة المستخدمين وتقييم التطبيق</p>
          </div>
          <Star className="h-5 w-5 text-primary flex-shrink-0" />
        </Card>
      </div>

      {/* Smart Commands Section */}
      <div className="mt-4">
        <h3 className="text-white font-semibold text-sm mb-3">مركز الأوامر الذكي</h3>
        <div className="grid grid-cols-2 gap-3">
          <Card className="p-4 rounded-2xl flex items-center justify-between cursor-pointer hover:shadow-lg transition-shadow">
            <div>
              <p className="text-xs text-muted-foreground">أمر ذكي</p>
            </div>
            <Shield className="h-5 w-5 text-primary" />
          </Card>
          <Card className="p-4 rounded-2xl flex items-center justify-between cursor-pointer hover:shadow-lg transition-shadow">
            <div>
              <p className="text-xs text-muted-foreground">أمر ذكي</p>
            </div>
            <Shield className="h-5 w-5 text-primary" />
          </Card>
        </div>
      </div>
    </div>
  );
}
