import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, MapPin, X } from "lucide-react";

interface Mountain {
  name_ar: string;
  name_en: string;
  elevation_m: number;
  risk_level: number;
  latitude: number;
  longitude: number;
}

const MOUNTAINS_DATA: Mountain[] = [
  {
    name_ar: "جبل السودة",
    name_en: "Jabal Al-Sawda",
    elevation_m: 3015,
    risk_level: 4,
    latitude: 18.2678,
    longitude: 42.3703,
  },
  {
    name_ar: "جبل فرواع",
    name_en: "Jabal Ferwa",
    elevation_m: 3004,
    risk_level: 4,
    latitude: 17.9283,
    longitude: 43.2656,
  },
  {
    name_ar: "جبل نطفاء",
    name_en: "Jabal Natfa'",
    elevation_m: 2965,
    risk_level: 4,
    latitude: 17.9178,
    longitude: 43.2908,
  },
  {
    name_ar: "جبل وراب",
    name_en: "Jabal Warrab",
    elevation_m: 2948,
    risk_level: 4,
    latitude: 17.9783,
    longitude: 43.2372,
  },
  {
    name_ar: "جبل طويق",
    name_en: "Tuwaiq Mountain",
    elevation_m: 1200,
    risk_level: 2,
    latitude: 24.5,
    longitude: 46.5,
  },
];

const getRiskColor = (level: number): string => {
  switch (level) {
    case 1:
      return "bg-green-900";
    case 2:
      return "bg-green-600";
    case 3:
      return "bg-yellow-500";
    case 4:
      return "bg-orange-600";
    case 5:
      return "bg-red-600";
    default:
      return "bg-gray-500";
  }
};

const getRiskLabel = (level: number): string => {
  switch (level) {
    case 1:
      return "خطورة منخفضة جداً";
    case 2:
      return "خطورة منخفضة";
    case 3:
      return "خطورة متوسطة";
    case 4:
      return "خطورة عالية";
    case 5:
      return "خطورة حرجة";
    default:
      return "غير محدد";
  }
};

export default function MapPage() {
  const [selectedMountain, setSelectedMountain] = useState<Mountain | null>(
    null
  );

  const latToPixel = (lat: number) => {
    return ((lat - 15) / (32 - 15)) * 100;
  };

  const longToPixel = (long: number) => {
    return ((long - 34) / (56 - 34)) * 100;
  };

  return (
    <div className="space-y-4 p-4 pb-24 bg-primary">
      {/* Map Container */}
      <div className="relative h-64 rounded-3xl border border-secondary/20 shadow-lg overflow-hidden bg-gradient-to-br from-secondary/30 to-primary">
        {/* Mountain markers */}
        {MOUNTAINS_DATA.map((mountain) => (
          <button
            key={mountain.name_ar}
            onClick={() => setSelectedMountain(mountain)}
            className="absolute -translate-x-1/2 -translate-y-1/2 transition-transform hover:scale-125"
            style={{
              left: `${longToPixel(mountain.longitude)}%`,
              top: `${latToPixel(mountain.latitude)}%`,
            }}
            title={mountain.name_ar}
          >
            <div
              className={`h-5 w-5 rounded-full border-2 border-white shadow-lg cursor-pointer ${getRiskColor(mountain.risk_level)}`}
            />
          </button>
        ))}

        {/* Legend */}
        <div className="absolute bottom-2 left-2 rounded-2xl bg-white/90 p-2 backdrop-blur text-xs">
          <p className="font-semibold mb-1">المستويات</p>
          <div className="space-y-1">
            {[
              { level: 4, label: "عالية" },
              { level: 2, label: "منخفضة" },
            ].map((item) => (
              <div key={item.level} className="flex items-center gap-1">
                <div className={`h-2 w-2 rounded-full ${getRiskColor(item.level)}`} />
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mountain Details or List */}
      {selectedMountain ? (
        <Card className="p-4 rounded-3xl">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h3 className="text-lg font-bold">{selectedMountain.name_ar}</h3>
              <p className="text-xs text-muted-foreground">
                {selectedMountain.name_en}
              </p>
            </div>
            <button
              onClick={() => setSelectedMountain(null)}
              className="p-1 hover:bg-secondary rounded"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">الارتفاع</span>
              <span className="font-semibold">
                {selectedMountain.elevation_m.toLocaleString()} م
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">مستوى الخطورة</span>
              <Badge
                className={`${getRiskColor(selectedMountain.risk_level)} text-white`}
              >
                {getRiskLabel(selectedMountain.risk_level)}
              </Badge>
            </div>

            {selectedMountain.risk_level >= 3 && (
              <div className="rounded-lg bg-yellow-50 p-3 mt-3">
                <div className="flex gap-2">
                  <AlertCircle className="h-4 w-4 flex-shrink-0 text-yellow-600 mt-0.5" />
                  <p className="text-xs text-yellow-800">
                    هذه المنطقة تتطلب مراقبة مستمرة
                  </p>
                </div>
              </div>
            )}
          </div>
        </Card>
      ) : null}

      {/* Mountains List */}
      <div>
        <h2 className="mb-3 font-bold text-white">قائمة الجبال</h2>
        <div className="space-y-2">
          {MOUNTAINS_DATA.map((mountain) => (
            <Card
              key={mountain.name_ar}
              onClick={() => setSelectedMountain(mountain)}
              className={`p-3 rounded-2xl cursor-pointer transition-colors ${
                selectedMountain?.name_ar === mountain.name_ar
                  ? "bg-secondary/20 border-secondary"
                  : "hover:bg-white/5"
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-sm">{mountain.name_ar}</h3>
                  <p className="text-xs text-muted-foreground">
                    {mountain.elevation_m.toLocaleString()} م
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`${getRiskColor(mountain.risk_level)} text-white text-xs`}>
                    {getRiskLabel(mountain.risk_level)}
                  </Badge>
                  <div
                    className={`h-3 w-3 rounded-full ${getRiskColor(mountain.risk_level)}`}
                  />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
