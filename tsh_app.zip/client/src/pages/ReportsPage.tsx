import { useState } from "react";
import { Upload, Send, AlertCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

export default function ReportsPage() {
  const { user, isAuthenticated } = useAuth();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    location: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // جلب البلاغات
  const { data: reports = [], isLoading } = trpc.reports.getAll.useQuery();
  const { data: userReports = [] } = trpc.reports.getByUser.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // إنشاء بلاغ جديد
  const createReportMutation = trpc.reports.create.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال البلاغ بنجاح!");
      setFormData({ title: "", description: "", location: "" });
      setSelectedFile(null);
    },
    onError: (error) => {
      toast.error("حدث خطأ في إرسال البلاغ");
      console.error(error);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.description || !formData.location) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    if (!isAuthenticated) {
      toast.error("يجب تسجيل الدخول أولاً");
      return;
    }

    setIsSubmitting(true);
    try {
      await createReportMutation.mutateAsync({
        title: formData.title,
        description: formData.description,
        location: formData.location,
        latitude: 24.7136,
        longitude: 46.6753,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("حجم الملف يجب أن يكون أقل من 5 ميجابايت");
        return;
      }
      setSelectedFile(file);
      toast.success("تم اختيار الملف بنجاح");
    }
  };

  return (
    <div className="space-y-4 p-4 pb-24">
      {/* نموذج إضافة بلاغ جديد */}
      {isAuthenticated && (
        <Card className="p-4 rounded-2xl bg-white">
          <h2 className="text-lg font-bold text-primary mb-4">إضافة بلاغ جديد</h2>
          
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                عنوان البلاغ
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="أدخل عنوان البلاغ"
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                الوصف
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="اشرح تفاصيل البلاغ"
                rows={3}
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                الموقع
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="أدخل موقع البلاغ"
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* رفع ملف */}
            <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
              <input
                type="file"
                id="file-input"
                onChange={handleFileChange}
                className="hidden"
                accept="image/*,.pdf"
              />
              <label htmlFor="file-input" className="cursor-pointer">
                <Upload className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-sm text-foreground font-medium">
                  {selectedFile ? selectedFile.name : "اضغط لرفع ملف أو صورة"}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  (الحد الأقصى 5 ميجابايت)
                </p>
              </label>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || createReportMutation.isPending}
              className="w-full bg-primary text-white font-semibold py-2 rounded-lg hover:bg-primary/90"
            >
              {isSubmitting || createReportMutation.isPending ? "جاري الإرسال..." : "إرسال البلاغ"}
              <Send className="h-4 w-4 ml-2" />
            </Button>
          </form>
        </Card>
      )}

      {!isAuthenticated && (
        <Card className="p-4 rounded-2xl bg-yellow-50 border border-yellow-200">
          <div className="flex gap-3">
            <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-yellow-800">
                يجب تسجيل الدخول لإضافة بلاغ جديد
              </p>
              <p className="text-xs text-yellow-700 mt-1">
                اضغط على أيقونة الإعدادات لتسجيل الدخول
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* قائمة البلاغات */}
      <div>
        <h2 className="text-lg font-bold text-primary mb-3">
          {isAuthenticated ? "بلاغاتي" : "آخر البلاغات"}
        </h2>
        
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">جاري التحميل...</p>
          </div>
        ) : (isAuthenticated ? userReports : reports).length === 0 ? (
          <Card className="p-6 rounded-2xl text-center">
            <p className="text-muted-foreground">لا توجد بلاغات</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {(isAuthenticated ? userReports : reports).map((report) => (
              <Card
                key={report.id}
                className="p-4 rounded-2xl border-l-4 border-l-primary"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-foreground">{report.title}</h3>
                  <span
                    className={`text-xs px-2 py-1 rounded-full font-medium ${
                      report.status === "new"
                        ? "bg-blue-100 text-blue-700"
                        : report.status === "reviewing"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-green-100 text-green-700"
                    }`}
                  >
                    {report.status === "new"
                      ? "جديد"
                      : report.status === "reviewing"
                      ? "قيد المراجعة"
                      : "تم حله"}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {report.description}
                </p>
                <p className="text-xs text-muted-foreground">
                  📍 {report.location}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(report.createdAt).toLocaleDateString("ar-SA")}
                </p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
