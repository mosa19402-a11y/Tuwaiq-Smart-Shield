import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("API Endpoints", () => {
  describe("mountains", () => {
    it("should get all mountains", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const mountains = await caller.mountains.getAll();
      expect(Array.isArray(mountains)).toBe(true);
    });

    it("should get mountain by id", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      // First get all mountains
      const mountains = await caller.mountains.getAll();
      
      if (mountains.length > 0) {
        const mountain = await caller.mountains.getById(mountains[0].id);
        expect(mountain).toBeDefined();
        expect(mountain?.id).toBe(mountains[0].id);
      }
    });
  });

  describe("alerts", () => {
    it("should get active alerts", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const alerts = await caller.alerts.getActive();
      expect(Array.isArray(alerts)).toBe(true);
    });

    it("should get alerts by mountain", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const alerts = await caller.alerts.getByMountain(1);
      expect(Array.isArray(alerts)).toBe(true);
    });
  });

  describe("reports", () => {
    it("should get all reports", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const reports = await caller.reports.getAll();
      expect(Array.isArray(reports)).toBe(true);
    });

    it("should get user reports when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);
      
      const reports = await caller.reports.getByUser();
      expect(Array.isArray(reports)).toBe(true);
    });

    it("should create a report when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);
      
      const newReport = {
        title: "Test Report",
        description: "This is a test report",
        location: "Test Location",
        latitude: 24.7136,
        longitude: 46.6753,
      };
      
      const report = await caller.reports.create(newReport);
      expect(report).toBeDefined();
      expect(report?.title).toBe("Test Report");
      expect(report?.userId).toBe(1);
    });
  });

  describe("files", () => {
    it("should get files by report", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const files = await caller.files.getByReport(1);
      expect(Array.isArray(files)).toBe(true);
    });

    it("should get user files when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);
      
      const files = await caller.files.getByUser();
      expect(Array.isArray(files)).toBe(true);
    });
  });

  describe("auth", () => {
    it("should get current user when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);
      
      const user = await caller.auth.me();
      expect(user).toBeDefined();
      expect(user?.id).toBe(1);
    });

    it("should return null when not authenticated", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      
      const user = await caller.auth.me();
      expect(user).toBeNull();
    });
  });
});
