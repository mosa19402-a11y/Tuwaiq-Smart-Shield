import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, mountains, alerts, reports, uploadedFiles, Mountain, Alert, Report, UploadedFile } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== دوال الجبال =====
export async function getAllMountains(): Promise<Mountain[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(mountains).orderBy(mountains.nameAr);
}

export async function getMountainById(id: number): Promise<Mountain | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(mountains).where(eq(mountains.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== دوال التنبيهات =====
export async function getActiveAlerts(): Promise<Alert[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(alerts).where(eq(alerts.isActive, true)).orderBy(desc(alerts.createdAt));
}

export async function getAlertsByMountain(mountainId: number): Promise<Alert[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(alerts).where(eq(alerts.mountainId, mountainId)).orderBy(desc(alerts.createdAt));
}

export async function createAlert(alert: any): Promise<Alert | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(alerts).values(alert);
  if (!result[0].insertId) return null;
  return await db.select().from(alerts).where(eq(alerts.id, result[0].insertId as number)).then(r => r[0]);
}

// ===== دوال البلاغات =====
export async function getAllReports(): Promise<Report[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reports).orderBy(desc(reports.createdAt));
}

export async function getReportsByUser(userId: number): Promise<Report[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reports).where(eq(reports.userId, userId)).orderBy(desc(reports.createdAt));
}

export async function createReport(report: any): Promise<Report | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(reports).values(report);
  if (!result[0].insertId) return null;
  return await db.select().from(reports).where(eq(reports.id, result[0].insertId as number)).then(r => r[0]);
}

export async function updateReportStatus(reportId: number, status: "new" | "reviewing" | "resolved"): Promise<Report | null> {
  const db = await getDb();
  if (!db) return null;
  await db.update(reports).set({ status }).where(eq(reports.id, reportId));
  return await db.select().from(reports).where(eq(reports.id, reportId)).then(r => r[0]);
}

// ===== دوال الملفات =====
export async function createUploadedFile(file: any): Promise<UploadedFile | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(uploadedFiles).values(file);
  if (!result[0].insertId) return null;
  return await db.select().from(uploadedFiles).where(eq(uploadedFiles.id, result[0].insertId as number)).then(r => r[0]);
}

export async function getFilesByReport(reportId: number): Promise<UploadedFile[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(uploadedFiles).where(eq(uploadedFiles.reportId, reportId));
}

export async function getFilesByUser(userId: number): Promise<UploadedFile[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(uploadedFiles).where(eq(uploadedFiles.userId, userId));
}
