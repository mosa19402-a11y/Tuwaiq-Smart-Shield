import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getAllMountains, getMountainById, getActiveAlerts, getAlertsByMountain, getAllReports, getReportsByUser, createReport, updateReportStatus, getFilesByReport, getFilesByUser, createUploadedFile } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  mountains: router({
    getAll: publicProcedure.query(() => getAllMountains()),
    getById: publicProcedure.input((val: unknown) => {
      if (typeof val === 'number') return val;
      throw new Error('Invalid input');
    }).query(({ input }) => getMountainById(input)),
  }),

  alerts: router({
    getActive: publicProcedure.query(() => getActiveAlerts()),
    getByMountain: publicProcedure.input((val: unknown) => {
      if (typeof val === 'number') return val;
      throw new Error('Invalid input');
    }).query(({ input }) => getAlertsByMountain(input)),
  }),

  reports: router({
    getAll: publicProcedure.query(() => getAllReports()),
    getByUser: protectedProcedure.query(({ ctx }) => getReportsByUser(ctx.user.id)),
    create: protectedProcedure.input((val: unknown) => val as any).mutation(({ input, ctx }) => 
      createReport({ ...input, userId: ctx.user.id })
    ),
    updateStatus: protectedProcedure.input((val: unknown) => val as any).mutation(({ input }) => 
      updateReportStatus(input.reportId, input.status)
    ),
  }),

  files: router({
    getByReport: publicProcedure.input((val: unknown) => {
      if (typeof val === 'number') return val;
      throw new Error('Invalid input');
    }).query(({ input }) => getFilesByReport(input)),
    getByUser: protectedProcedure.query(({ ctx }) => getFilesByUser(ctx.user.id)),
    create: protectedProcedure.input((val: unknown) => val as any).mutation(({ input, ctx }) => 
      createUploadedFile({ ...input, userId: ctx.user.id })
    ),
  }),
});

export type AppRouter = typeof appRouter;
